g++ Main.cpp -lGLU -lGL -lglut -lGLEW -lX11 -Wwrite-strings -lz -lm -lpthread -I/usr/include
